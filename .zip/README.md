# heartpred

A heart disease classifying project using random forest and xgboost as the classifying models.

# Dataset

[Kaggle Dataset: heart-disease-cleveland](https://www.kaggle.com/datasets/ritwikb3/heart-disease-cleveland/)
